function scanForMp4() {
  const links = new Set();
  
  const elements = document.querySelectorAll('video, source, a');
  elements.forEach(el => {
    const src = el.src || el.href;
    if (src && src.toLowerCase().includes('.mp4')) {
      links.add(src);
    }
  });

  links.forEach(url => {
    chrome.runtime.sendMessage({ type: 'MP4_FOUND', url: url }).catch(() => {});
  });
}

// Initial scan
scanForMp4();

// Observe dynamically added elements
const observer = new MutationObserver((mutations) => {
  let shouldScan = false;
  for (let mutation of mutations) {
    if (mutation.addedNodes.length > 0) {
      mutation.addedNodes.forEach(node => {
        if (node.tagName === 'VIDEO' || node.tagName === 'SOURCE' || node.tagName === 'A') {
          shouldScan = true;
        } else if (node.querySelectorAll) {
          if (node.querySelectorAll('video, source, a').length > 0) {
            shouldScan = true;
          }
        }
      });
    }
    if (shouldScan) break;
  }
  
  if (shouldScan) {
    scanForMp4();
  }
});

if (document.body) {
  observer.observe(document.body, { childList: true, subtree: true });
} else {
  document.addEventListener('DOMContentLoaded', () => {
    observer.observe(document.body, { childList: true, subtree: true });
  });
}
