let tabLinks = {};
let blinkIntervals = {};

// Listen to network requests for .mp4 or MIME type video/mp4
chrome.webRequest.onHeadersReceived.addListener(
  (details) => {
    if (details.tabId < 0) return;
    
    let isMp4 = false;
    if (details.url.toLowerCase().includes('.mp4')) {
      isMp4 = true;
    } else {
      for (let header of details.responseHeaders) {
        if (header.name.toLowerCase() === 'content-type' && header.value.toLowerCase().includes('video/mp4')) {
          isMp4 = true;
          break;
        }
      }
    }

    if (isMp4) {
      addLink(details.tabId, details.url);
    }
  },
  { urls: ["<all_urls>"] },
  ["responseHeaders"]
);

// Listen to messages from content script
chrome.runtime.onMessage.addListener((message, sender) => {
  if (message.type === 'MP4_FOUND' && sender.tab) {
    addLink(sender.tab.id, message.url);
  }
});

function addLink(tabId, url) {
  if (!tabLinks[tabId]) {
    tabLinks[tabId] = new Set();
  }
  
  if (!tabLinks[tabId].has(url)) {
    tabLinks[tabId].add(url);
    startBlinking(tabId);
  }
}

function startBlinking(tabId) {
  if (blinkIntervals[tabId]) {
    clearInterval(blinkIntervals[tabId]);
  }
  
  let isRed = true;
  chrome.action.setBadgeText({ text: "MP4", tabId: tabId });
  
  // Blink 6 times (3 cycles)
  let count = 0;
  blinkIntervals[tabId] = setInterval(() => {
    if (isRed) {
      chrome.action.setBadgeBackgroundColor({ color: "#FF0000", tabId: tabId });
    } else {
      chrome.action.setBadgeBackgroundColor({ color: "#FFD700", tabId: tabId }); // Gold
    }
    isRed = !isRed;
    count++;
    
    if (count > 6) {
      clearInterval(blinkIntervals[tabId]);
      delete blinkIntervals[tabId];
      chrome.action.setBadgeBackgroundColor({ color: "#FF0000", tabId: tabId }); // Leave at red
    }
  }, 300);
}

// Click action
chrome.action.onClicked.addListener((tab) => {
  const links = tabLinks[tab.id];
  if (links && links.size > 0) {
    const urlsText = Array.from(links).join('\n');
    
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: (text) => {
        // Create a temporary textarea to copy text to clipboard
        const textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.style.position = 'fixed';  // Prevent scrolling to bottom of page in MS Edge.
        document.body.appendChild(textarea);
        textarea.select();
        
        try {
          const successful = document.execCommand('copy');
          if (successful) {
            alert('MP4 링크가 클립보드에 복사되었습니다!\n\n' + text);
          } else {
            alert('복사 실패. 콘솔을 확인해주세요.');
          }
        } catch (err) {
          console.error('클립보드 복사 에러:', err);
        }
        
        document.body.removeChild(textarea);
      },
      args: [urlsText]
    });
    
    // Clear badge
    chrome.action.setBadgeText({ text: "OK", tabId: tab.id });
    chrome.action.setBadgeBackgroundColor({ color: "#00FF00", tabId: tab.id });
  } else {
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        alert('발견된 MP4 링크가 없습니다.');
      }
    });
  }
});

// Cleanup when tab is closed or updated
chrome.tabs.onRemoved.addListener((tabId) => {
  delete tabLinks[tabId];
  if (blinkIntervals[tabId]) {
    clearInterval(blinkIntervals[tabId]);
    delete blinkIntervals[tabId];
  }
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === 'loading' && changeInfo.url) {
    delete tabLinks[tabId];
    if (blinkIntervals[tabId]) {
      clearInterval(blinkIntervals[tabId]);
      delete blinkIntervals[tabId];
    }
    chrome.action.setBadgeText({ text: "", tabId: tabId });
  }
});
